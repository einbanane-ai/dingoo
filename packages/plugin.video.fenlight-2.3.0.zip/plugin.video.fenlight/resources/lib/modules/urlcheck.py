# -*- coding: utf-8 -*-
# Fen Light dead-link check (adapted from luc_kodi's urlcheck, SAFE mode).
#
# Purpose: right before playback, quickly verify a resolved source URL actually
# points at a playable stream and skip it if it is clearly dead. This is what
# lets Fen Light "filter out dead links" instead of handing them to the player
# and hanging until it times out.
#
# SAFE mode design: only return False (dead) on a DEFINITE dead signal:
#   - HTTP status >= 400
#   - an HTML/text "fake video" error page pretending to be a stream
# On a timeout, connection error, or anything ambiguous we return True (allow),
# so a momentary network hiccup can never kill an otherwise-good source.

import ssl
import urllib.request as urllib2
from urllib.parse import parse_qsl
from modules import kodi_utils
# logger = kodi_utils.logger

_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'


def check_url_validity(url, headers=None, timeout=6):
	try:
		if not url: return False
		low = url.lower()
		# Non-http playback targets (plugin resolvers, magnets, rtmp) can't be
		# HTTP-checked here - never treat them as dead.
		if low.startswith(('plugin://', 'special://', 'magnet:', 'rtmp://', 'rtsp://')): return True
		if not low.startswith(('http://', 'https://')): return True

		clean_url = url
		hdrs = {'User-Agent': _UA}
		if isinstance(headers, dict): hdrs.update(headers)
		# Kodi pipe-header syntax: url|Header=Value&Header2=Value2
		if '|' in url:
			clean_url, qs = url.split('|', 1)
			try: hdrs.update(dict(parse_qsl(qs)))
			except: pass

		try: ctx = ssl._create_unverified_context()
		except: ctx = None

		req = urllib2.Request(clean_url, headers=hdrs)
		with urllib2.urlopen(req, timeout=timeout, context=ctx) as resp:
			try: code = resp.getcode() or 200
			except: code = 200
			if int(code) >= 400:
				kodi_utils.logger('Fen Light Dead Link', 'HTTP %s: %s' % (code, clean_url))
				return False
			try: chunk = resp.read(512) or b''
			except: chunk = b''
			content_str = chunk.decode('utf-8', errors='ignore')
			# A) HLS playlist -> allow (often served as text/plain)
			if '#EXTM3U' in content_str: return True
			# B) Content-Type says video/binary -> allow
			try: ctype = (resp.headers.get('Content-Type') or '').lower()
			except: ctype = ''
			if any(t in ctype for t in ('video', 'application/octet-stream', 'mpegurl', 'm3u8', 'mp4', 'matroska')): return True
			# C) HTML/text error page pretending to be a stream -> dead
			if ('text' in ctype) or ('html' in ctype) or ('<html' in content_str.lower()):
				kodi_utils.logger('Fen Light Dead Link', 'HTML/text fake video: %s' % clean_url)
				return False
			# D) Anything else (unknown but reachable) -> allow, SAFE mode
			return True
	except Exception as e:
		# Timeout / connection error / anything ambiguous -> allow (SAFE mode).
		kodi_utils.logger('Fen Light Dead Link Check', 'skipped (allowed) due to: %s' % e)
		return True
